# Introduction
#
This model is converted from the following repository.
https://github.com/MycroftAI/mimic3-voices/tree/master/voices/af_ZA/google-nwu_low
