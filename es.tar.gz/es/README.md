# Introduction

This mode is converted from
https://drive.google.com/file/d/12tNCCyd0Hf5jsyqCw8828kLSHHx5LOw9/view

Please see also
https://github.com/rhasspy/piper/issues/187#issuecomment-1802216304

