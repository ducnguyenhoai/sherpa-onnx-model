# Introduction
#
This model is converted from the following repository.
https://github.com/MycroftAI/mimic3-voices/tree/master/voices/ko_KO/kss_low
