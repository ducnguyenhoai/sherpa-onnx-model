# Introduction
#
This model is converted from the following repository.
https://github.com/MycroftAI/mimic3-voices/tree/master/voices/gu_IN/cmu-indic_low
